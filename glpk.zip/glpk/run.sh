#!/bin/bash
glpsol --math crypto.mod
